function onParillinen()
{
  var luku = parseInt(document.getElementById('parillinen').value);
  var luvut = "";
  for(var i = luku; i <=10; i+=2)
  {
    if(i%2 == 0 && i <= 10)
    {
      luvut += i + ' ';
    }
    else {
        luvut = 'Et antanut parillista';
    }

  }

  document.getElementById('tulostaTahan').innerHTML = luvut;
}


function Salasana()
{
  var sana = document.getElementById('Sana').value;
  var uusisalis ='';
  for(var j = 0; j < sana.length; j++)
  {
    uusisalis += sana[j] + 'Ö';
  }
  document.getElementById('tulostaTahan2').innerHTML = uusisalis;
}

function Okirjain()
{
  var kirjain = document.getElementById('kirjain').value;
  for (var t = 0; t < kirjain.length; t++) {
    if (kirjain[t] == 'ö'  || kirjain[t] == 'Ö')  {
      document.getElementById('tulostaTahan3').innerHTML = 'Sanasta löytyy ö';
    }
      else
        document.getElementById('tulostaTahan3').innerHTML = 'Ei löydy ö kirjainta';
      }
}


function Lasku()
{
  var kertolasku = document.getElementById('kerto').value;
  var kerrottava = 1;
  for (var i = 1; i < kertolasku; i++) {
    kerrottava*=kertolasku;{
  }
  document.getElementById('tulostaTahan4').innerHTML = '<p>luvun ' + kertolasku + ' kertoma on' + kerrottava +'</p>';
}
}

function hipheijaa()
{
  var tulosta = '';
  for (var e = 1; e <= 100; e++) {

      if (e%3==0) {
      tulosta += 'Hip ';
    }
      else if (e%5==0) {
      tulosta += 'Heijaa ';
   }
      else if (e%3==0 && e%5==0) {
        tulosta += 'Hip Heijaa ';
      }
      else {
        tulosta+=e+' ';
      }
      document.getElementById('tulostaTahan5').innerHTML = tulosta;
    }
  }


function Ensimmainen()
{
  var kymmenen = '';
  for (var a = 1; a <= 10; a++) {
    kymmenen += a + ' ';
  }
    document.getElementById('tulostaTahan6').innerHTML = kymmenen;
  }



function Yhteenlasku()
{
var yhteen =0;
for (var s = 1; s <= 10; s++) {
  yhteen += s;
}
document.getElementById('tulostaTahan7').innerHTML = yhteen;
}


function Potenssi()
{
  var korotus = document.getElementById('koro').value;
  var potenssi = document.getElementById('pote').value;
  var temp = 1;
  for (var p = 1; p <= potenssi; p++)
{
    temp*=korotus;
  }
  document.getElementById('tulostaTahan8').innerHTML = temp;
}


function etsiLuku()
{
  var l1 = document.getElementById('eka').value;
  var l2 = document.getElementById('toka').value;
  var l3 = document.getElementById('kolmas').value;
  var l4 = document.getElementById('neljas').value;
  var l5 = document.getElementById('viides').value;

  if(l1 < l2 && l3 < l2 && l4 < l2 && l5 < l2)
     {
       suurin = l2;
     }
     else if(l1 < l3 && l4 < l3 && l5 < l3)
     {
       suurin = l3;
     }
     else if(l1 < l4 && l5 < l4)
     {
       suurin = l4;
     }
     else if(l1 < l5)
     {
       suurin = l5;
     }
     else {
       suurin = l1;
     }

     if(l1 > l2 && l3 > l2 && l4 > l2 && l5 > l2)
        {
          pienin = l2;
        }
        else if(l1 > l3 && l4 > l3 && l5 > l3)
        {
          pienin = l3;
        }
        else if(l1 > l4 && l5 > l4)
        {
          pienin = l4;
        }
        else if(l1 > l5)
        {
          pienin = l5;
        }
        else {
          pienin = l1;
        }
     document.write("Annoit luvut: " + l1 + ' ' + l2 + ' ' + l3 + ' ' + l4 + ' ' + l5);
     document.write("<br>pienin niistä on: " + pienin);
     document.write("<br>Suurin niistä on: " + suurin);
   }


function Uusisala()
{
  var sana = document.getElementById('salis').value;
  var uusisala = '';
  var kirjaimet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j','k', 'l', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u','v', 'x', 'y', 'z', 'å', 'ä', 'ö', 'w'];
  for (var q = 0; q < sana.length; q++)
       uusisala+=sana[q] + Math.floor(Math.random()*kirjaimet.length);
    
{
  document.getElementById('tulostaTahan10').innerHTML = uusisala;
}
}
