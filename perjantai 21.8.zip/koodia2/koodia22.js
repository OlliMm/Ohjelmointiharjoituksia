function tehtava1()
{
  var luku;
  luku = document.getElementById('eka').value;
if (luku >= 0)
  document.write('luku on positiivinen')


else {
  document.write('luku on negatiivinen')
}
}

function viikonpaiva()

{
  var paiva = document.getElementById('paiva').value;
  if(paiva == 1)
  {
    document.write('Maanantai')
  }
  else if(paiva == 2)
  {
    document.write('Tiistai')
  }
  else if(paiva == 3)
  {
    document.write('Keskiviikko')
  }
  else if(paiva == 4)
  {
    document.write('Torstai')
  }
  else if(paiva == 5)
  {
    document.write('Perjantai')
  }
  else if(paiva == 6)
  {
    document.write('Lauantai')
  }
  else if(paiva == 7)
  {
    document.write('Sunnuntai')
  }
  else {
      document.write('Luku ei kuulu viikonpaivalle')
  }
}



function karkausvuosi()
{
  var paiva;
  paiva = document.getElementById('paivamaara').value;

  if(paiva%4 == 0 && paiva%100 != 0)
   {
     document.write('karkausvuosi')
   }
   else if(paiva%400 ==0) {
     document.write('karkausvuosi')
   }
   else {
     document.write('Ei ole karkausvuosi')
   }
 }

 function summak()
 {
   var l1, l2, l3, l4, l5, summa, keskiarvo;
     l1 = document.getElementById('l1').value;
     l2 = document.getElementById('l2').value;
     l3 = document.getElementById('l3').value;
     l4 = document.getElementById('l4').value;
     l5 = document.getElementById('l5').value;

// Summa ei laske numeroita yhteen. //

     summa = l1 + l2 + l3 + l4 + l5;
    document.write("Lukujen summa on: " + summa)
    {
      keskiarvo = summa /5;
      document.write("Keskiarvo : " + summa /5)
    }
}

function kertotaulu()
{
  var l1;
  l1 = document.getElementById('l1').value;
}

var taulu = l1 + ' x 0 = '+ l1*0;
taulu += l1 + ' x 1 = '+ l1*1;
taulu += l1 + ' x 2 = '+ l1*2;
taulu += l1 + ' x 3 = '+ l1*3;
taulu += l1 + ' x 4 = '+ l1*4;
taulu += l1 + ' x 5 = '+ l1*5;
taulu += l1 + ' x 6 = '+ l1*6;
taulu += l1 + ' x 7 = '+ l1*7;
taulu += l1 + ' x 8 = '+ l1*8;
taulu += l1 + ' x 9 = '+ l1*9;
taulu += l1 + ' x 10 = '+ l1*10;
document.write('Taulu :');
