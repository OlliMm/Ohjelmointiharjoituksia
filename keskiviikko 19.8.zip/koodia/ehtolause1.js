function jarjestaLuvut()
{
  var l1, l2, l3;
  l1 = document.getElementById('eka').value;
  l2 = document.getElementById('toka').value;
  l3 = document.getElementById('kolmas').value;
  if (l1 < l2 && l1 < l3)
  {
    if (l2 < l3)
    {
      document.write('Lukujen järjestys: ' + l1 + ' ' + l2 + ' ' + l3);
    }
    else {
      document.write('Lukujen järjestys: ' + l1 + ' ' + l3 + ' ' + l2);
    }
  }
  else if(l2 < l1 && l2 < l3)
  {
    if (l1<l3)
    {
      document.write('Lukujen järjestys: ' + l2 + ' ' + l1 + ' ' + l3);
    }
    else
    {
      document.write('Lukujen järjestys: ' + l2 + ' ' + l3 + ' ' + l1);
    }
  }
  else if(l3 < l2 && l3 < l1)
    {
      if (l2<l1)
      {
        document.write('Lukujen järjestys: ' + l3 + ' ' + l2 + ' ' + l1);
      }
      else
      {
        document.write('Lukujen järjestys: ' + l3 + ' ' + l1 + ' ' + l2);
      }
    }
  }

  function jarjestaLuvut2()
  {
      var l1, l2, l3, l4, l5, suurin;
      l1 = document.getElementById('l1').value;
      l2 = document.getElementById('l2').value;
      l3 = document.getElementById('l3').value;
      l4 = document.getElementById('l4').value;
      l5 = document.getElementById('l5').value;


      /*
En osannut tätä tehtävää katsoin mallin.
*/

      if(l1 < l2 && l3 < l2 && l4 < l2 && l5 < l2)
         {
           suurin = l2;
         }
         else if(l1 < l3 && l4 < l3 && l5 < l3)
         {
           suurin = l3;
         }
         else if(l1 < l4 && l5 < l4)
         {
           suurin = l4;
         }
         else if(l1 < l5)
         {
           suurin = l5;
         }
         else {
           suurin = l1;
         }
         document.write("Annoit luvut: " + l1 + ' ' + l2 + ' ' + l3 + ' ' + l4 + ' ' + l5);
         document.write("<br>Suurin niistä on: " + suurin);
       }



function Kaannos()
{
  var hieli = document.getElementById('kieli').value;
  if(hieli == 'eng')
  {
    document.write('Hello World');
  }
  if
    (hieli == 'swe')
  {
    document.write('Hej världen');
  }
  else {
    (hieli == 'esp')
    document.write('Hola Mundo');
}
}

function jarjestaLuvut3()
{
  var luku = document.getElementById('luku').value;
  if(luku % 2 == 0)
document.write('lukusi on Parillinen');
  else{
  document.write('lukusi on pariton');
}
}

function ajoneuvo()
{
  var ika = document.getElementById('ika').value;
  if(ika<= 15)
  document.write('Voit ajaa polkupyörää');

  else if
    (ika <=18)
    document.write('voit ajaa mopoa');

else {
(ika >=18)
document.write('voit ajaa autoa');

}
}
